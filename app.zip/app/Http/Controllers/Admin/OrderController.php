<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\Models\User;
use App\Models\Producto;
use App\Models\Precio;
use App\Models\Taxes;
use App\Models\Order;
use Illuminate\Http\Request;

class OrderController extends Controller
{

    public function listOrders()
    {
        $orders = Order::with('product', 'taxes', 'user')->latest()->get();
        $products = Producto::all();
        $precios = Precio::all();
        $taxes = Taxes::all();
        $users = User::all();
        return view('administrador/wholesale_orders', compact('orders', 'products', 'precios', 'taxes', 'users'));
    }

    public function createOrders()
    {
        $orders = Order::with('product', 'taxes', 'user')->get();
        $products = Producto::all();
        $precios = Precio::all();
        $taxes = Taxes::all();
        $users = User::all();
        return view('administrador/wholesale_new_order', compact('orders', 'products', 'precios', 'taxes', 'users'));
    }

    public function buscarClientes(Request $request)
    {
        $clientes = User::where('nombre', 'LIKE', '%' . $request->input('q') . '%')->select('id', 'nombre')->get();

        return response()->json($clientes);
    }

    public function calcularTotales(Request $request)
    {
        $request->validate([
            'usuario_id' => 'required|exists:users,id',
            'destino' => 'required|string',
            'productos' => 'required|array|min:1',
            'productos.*.producto_id' => 'required|exists:productos,id',
            'productos.*.tipo' => 'required|in:pallet,box',
            'productos.*.cantidad' => 'required|integer|min:1',
        ]);

        $usuarioId = (int) $request->usuario_id;
        $destino = $request->destino;
        $productos = $request->productos;

        $user = User::with('wholesPrice')->find($usuarioId);

        $descuentoPorcentaje = $user && $user->wholesPrice
            ? (float) ($user->wholesPrice->descuentos ?? 0)
            : 0.0;

        $totalProducts = 0.0;
        $totalShippingTaxes = 0.0;
        $detalleProductos = [];

        foreach ($productos as $item) {
            $productoModel = Producto::find($item['producto_id']);
            if (!$productoModel) continue;

            $tipoFrontend = $item['tipo'];
            $tipoTax = $tipoFrontend === 'pallet' ? 'pallets' : 'boxes';

            $cantidad = (int) $item['cantidad'];
            $precioUnitario = $tipoFrontend === 'pallet'
                ? (float) $productoModel->precio_pallets
                : (float) $productoModel->precio_boxes;

            $subtotalProduct = $precioUnitario * $cantidad;

            // Aplica descuento
            $subtotalConDescuento = $descuentoPorcentaje > 0
                ? $subtotalProduct * (1 - ($descuentoPorcentaje / 100))
                : $subtotalProduct;

            $shippingTax = Taxes::where('destino', $destino)
                                ->where('tipo', $tipoTax)
                                ->first();

            $shippingTaxAmount = 0.0;
            if ($shippingTax) {
                $shippingTaxAmount = (float) $shippingTax->total * $cantidad;
            }

            $totalProducts += $subtotalConDescuento;
            $totalShippingTaxes += $shippingTaxAmount;

            $detalleProductos[] = [
                'producto_id' => $productoModel->id,
                'nombre' => $productoModel->nombre,
                'tipo' => $tipoFrontend,
                'cantidad' => $cantidad,
                'precio_unitario' => $precioUnitario,
                'subtotal' => round($subtotalConDescuento, 2),
                'shipping_tax' => round($shippingTaxAmount, 2), // Cambio: shipping + tax
                'shipping_tax_breakdown' => $shippingTax ? [
                    'taxes' => $shippingTax->taxes,
                    'intercom' => $shippingTax->intercom,
                    'profit' => $shippingTax->profit,
                    'total' => $shippingTax->total
                ] : null
            ];
        }

        return response()->json([
            'total_products' => round($totalProducts, 2),
            'shipping_taxes' => round($totalShippingTaxes, 2), // Cambio: shipping + taxes
            'descuento' => $descuentoPorcentaje,
            'total_final' => round($totalProducts + $totalShippingTaxes, 2),
            'detalle_productos' => $detalleProductos,
        ]);
    }

    public function addOrder(Request $request)
    {
        $request->validate([
            'usuario_id' => 'required|exists:users,id',
            'destino' => 'required|string',
            'address' => 'required|string',
            'productos' => 'required|array|min:1',
            'productos.*.producto_id' => 'required|exists:productos,id',
            'productos.*.tipo' => 'required|in:pallet,box',
            'productos.*.cantidad' => 'required|integer|min:1',
        ]);
    
        $usuarioId = $request->usuario_id;
        $destino = $request->destino;
        $address = $request->address;
        $productos = $request->productos;
    
        $user = User::with('wholesPrice')->find($usuarioId);
        $descuentoPorcentaje = $user && $user->wholesPrice
            ? (float) ($user->wholesPrice->descuentos ?? 0)
            : 0.0;
    
        $totalFinal = 0.0;
        $orders = [];
    
        foreach ($productos as $item) {
            $productoModel = Producto::find($item['producto_id']);
            $tipoTax = $item['tipo'] === 'pallet' ? 'Pallets' : 'Boxes';
            
            $cantidad = (int) $item['cantidad'];
            $precioUnitario = $item['tipo'] === 'pallet'
                ? (float) $productoModel->precio_pallets
                : (float) $productoModel->precio_boxes;
    
            $subtotalProduct = $precioUnitario * $cantidad;
            
            // Aplicar descuento
            $subtotalConDescuento = $descuentoPorcentaje > 0
                ? $subtotalProduct * (1 - ($descuentoPorcentaje / 100))
                : $subtotalProduct;
    
            // 🔥 NUEVO: Obtener shipping + taxes dinámicamente
            $shippingTax = Taxes::where('destino', $destino)
                                ->where('tipo', $tipoTax)
                                ->first();
    
            $shippingTaxAmount = 0.0;
            if ($shippingTax) {
                $shippingTaxAmount = (float) $shippingTax->total * $cantidad;
            }
    
            $totalProducto = $subtotalConDescuento + $shippingTaxAmount;
            $totalFinal += $totalProducto;
    
            // Generar códigos únicos
            $lastOrder = Order::latest()->first();
            $nextId = $lastOrder ? $lastOrder->id + 1 : 1;
            $codigoShipment = 'SHI-' . str_pad($nextId, 4, '0', STR_PAD_LEFT);
            $codigoContainer = 'CONT-' . str_pad($nextId, 4, '0', STR_PAD_LEFT);
    
            // Crear orden
            $orders[] = Order::create([
                'shipment_id' => $codigoShipment,
                'container' => $codigoContainer,
                'destino' => $destino,
                'address' => $address,
                'producto_id' => $productoModel->id,
                'usuario_id' => $usuarioId,
                'taxes_id' => $shippingTax ? $shippingTax->id : null, // 🔥 NUEVO: Relación con taxes
                'total' => $totalProducto,
                'cantidad' => $cantidad,
                'tipo' => $item['tipo'],
            ]);
        }
    
        return response()->json([
            'success' => true,
            'message' => 'Orders created successfully',
            'orders' => $orders,
            'total_final' => $totalFinal
        ]);
    }


    public function editOrder(Request $request, $id)
    {
        $orders = Order::findOrFail($id);
        $products = Producto::all();
        $taxes = Taxes::all();
        $users = User::all();
        $precios = Precio::all();
        return view('dashboard-admin.orders', compact('orders', 'products', 'taxes', 'users', 'precios'));
    }


    public function getShippingTaxes($destino, $tipo)
    {
        $tipoTax = $tipo === 'pallet' ? 'Pallets' : 'Boxes';
        
        return Taxes::where('destino', $destino)
                    ->where('tipo', $tipoTax)
                    ->first();
    }

    public function deleteOrder($id)
    {
        $order = Order::findOrFail($id);
        $order->delete();
        return redirect()->route('dashboard-admin.orders')->with('success', 'Order deleted successfully.');
    }
}
